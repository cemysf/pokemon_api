from django.apps import AppConfig


class PokemonConfig(AppConfig):
    name = 'pokemon'
